package com.example.localonlinesong.localonlinesong.models;

import java.util.ArrayList;

public class SongsCollector {
    public static int song_total_number = 0;
    private static ArrayList<Song> mySongs = new ArrayList<>();

    public static Song getSong(int index){
        return mySongs.get(index);
    }

    public static void addSong(Song song){
        mySongs.add(song);
        song_total_number++;
    }

    public static void clearSong(){
        mySongs.clear();
        song_total_number=0;
        mySongs = new ArrayList<>();
    }

    public static void removeSong(int index){//根据位置移除
        mySongs.remove(index);
        song_total_number--;
    }
    //重载
    public static void removeSong(String dataPath){//根据路径移除
        for (int i=0; i < mySongs.size(); i++) {
            Song s = mySongs.get(i);
            if (s.getDataPath().equals(dataPath)) {
                mySongs.remove(i);
                break;
            }
        }
    }
    /**
     * 获取song数量*/
    public static int size(){
        return song_total_number;
    }
    /**
     * 返回songs_list对象
     * */
    public static ArrayList<Song> getSongsList(){
        return mySongs;
    }
    /**
     * 设置songs_list对象
     *
     */
    public static void setSongsList(ArrayList<Song> songs){
        mySongs = songs;
        song_total_number = songs.size();
    }

    /**
     * 判断是否已经有这首歌曲*/
    public static boolean isContainSong(String dataPath){
        for (Song mySong : mySongs) {
            if (mySong.getDataPath().equals(dataPath)) {
                return true;
            }
        }
        return false;
    }

    public static int getSongIndex(Song song){
        int result = 0;
        for(int i=0; i < mySongs.size(); i++){
            if(mySongs.get(i).getDataPath().equals(song.getDataPath())){
                result = i;
                break;
            }
        }
        return  result;
    }
}
