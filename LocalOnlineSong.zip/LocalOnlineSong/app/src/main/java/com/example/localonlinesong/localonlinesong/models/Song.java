package com.example.localonlinesong.localonlinesong.models;

import android.graphics.Bitmap;

public class Song {
    private String title;
    private String artist;
    private long duration;
    private String dataPath;
    private boolean isLove;
    private Bitmap album_icon;
    private boolean isDefaultAlbumIcon;
    private boolean isOnline;

    public Song(){}
    public Song(String title, String artist, long duration, String dataPath,
                boolean isLove, Bitmap album_icon, boolean isDefaultAlbumIcon, boolean isOnline) {
        this.title = title;
        this.artist = artist;
        this.duration = duration;
        this.dataPath = dataPath;
        this.isLove = isLove;
        this.album_icon = album_icon;
        this.isDefaultAlbumIcon = isDefaultAlbumIcon;
        this.isOnline=isOnline;
    }
    public Bitmap getAlbum_icon() {
        return album_icon;
    }
    public void setAlbum_icon(Bitmap album_icon) {
        this.album_icon = album_icon;
    }

    public void setLove(boolean love) {
        isLove = love;
    }

    public void setTitle(String str) { this.title = str; }

    public void setArtist(String str) { this.artist = str; }

    public void setDuration(long duration) { this.duration = duration; }

    public void setDataPath(String dataPath) { this.dataPath = dataPath; }

    public String getTitle() { return this.title; }

    public String getArtist() { return this.artist; }

    public long getDuration() { return duration; }

    public String getDataPath() { return dataPath; }

    public boolean isLove() {
        return isLove;
    }

    public boolean isDefaultAlbumIcon() {
        return isDefaultAlbumIcon;
    }

    public void setFlagDefaultAlbumIcon(boolean flagDefaultAlbumIcon) {
        isDefaultAlbumIcon = flagDefaultAlbumIcon;
    }

    public boolean isOnline() {
        return isOnline;
    }

    public void setOnline(boolean online) {
        isOnline = online;
    }
}
