package com.example.localonlinesong.localonlinesong.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.MediaStore;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;


import com.example.localonlinesong.localonlinesong.DP.HandleDbFunction;
import com.example.localonlinesong.localonlinesong.R;
import com.example.localonlinesong.localonlinesong.adapter.SongAdapter;
import com.example.localonlinesong.localonlinesong.models.Song;
import com.example.localonlinesong.localonlinesong.models.SongsCollector;
import com.example.localonlinesong.localonlinesong.utils.PictureDealHelper;

import java.lang.ref.WeakReference;

public class MainActivity extends AppCompatActivity {
    private Toolbar toolbar = null;//toolbar
    private SongAdapter adapter_main_song_list_view;//歌曲列表的适配器
    private SongAdapter adapter_history;
    private ProgressBar progressBar_activity_display = null;
    private ImageView album_icon = null;//专辑图片
    private TextView play_bar_song_name = null;//歌曲名字
    private TextView play_bar_song_author = null;//歌手
    private ImageButton play_bar_btn_play = null;
    private View history_view = null;
    private ListView drawer_layout_list_view = null;
    private AlertDialog dialog = null;
    private DrawerLayout drawerlayout = null;
    private TextView tv_intput = null;
    private HandleDbFunction handleDbFunction;
    private int current_progress = 0;//当前播放进度
    private int current_number = 0;//当前播放的第几首歌
    private int input_time = 0;
    private boolean pause_task_flag = false;
    private double rest_of_time = 0;
    private final int REQ_READ_EXTERNAL_STORAGE = 1;
    private int default_playMode = 0;
    private CountDownTimer countDownTimer = null;
    private int actual_number=0;
    public static final String HTTP_ROOT = "http://192.168.137.1:8088/";
    private String result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getLocalMusic();
    }
    private void getLocalMusic(){
        SongsCollector.clearSong();
        /*toolbar相关*/
        initMyToolbar("本地音乐");
        load_Songs_data();
    }
    private void initMyToolbar(String title){
        toolbar = findViewById(R.id.toolbar_activity_display);
//        drawer_layout_list_view = findViewById(R.id.drawer_layout_list);
        setSupportActionBar(toolbar);
        toolbar.setTitle(title);
    }
    /*加载歌曲数据*/
    private void load_Songs_data() {
        if (SongsCollector.size() == 0) {//保存的列表没数据
            handleDbFunction = HandleDbFunction.getInstance(this);//获取数据库操作类实例
            if (!handleDbFunction.isSONGS_Null()) {
                new GetDB_DataTask(MainActivity.this).execute();
                return;
            }
            /*判断是否需要请求权限,然后获取歌曲数据*/
            requestPermissionByHand();
        }else{
              initMySongListView();
        }
    }
    private static class GetDB_DataTask extends AsyncTask<Void,Void,Boolean> {
        private final WeakReference<MainActivity> displayActivityWeakReference ;
        GetDB_DataTask(MainActivity displayActivity){
            displayActivityWeakReference = new WeakReference<>(displayActivity);
        }



        @Override
        protected void onPreExecute() {
            MainActivity displayActivity = displayActivityWeakReference.get();
        }
        @Override
        protected Boolean doInBackground(Void... params) {
            MainActivity displayActivity = displayActivityWeakReference.get();
            if(displayActivity != null){
                if(displayActivity.handleDbFunction != null){
                    if (!displayActivity.handleDbFunction.isSONGS_Null()) {
                        SongsCollector.setSongsList(displayActivity.handleDbFunction.loadAllSongs());
                        return true;
                    }
                }
            }
            return false;
        }
        @Override
        protected void onPostExecute(Boolean result) {
            MainActivity displayActivity = displayActivityWeakReference.get();
            if (result) {
                displayActivity.initMySongListView();
            } else {
                Toast.makeText(displayActivity, "加载歌曲数据失败", Toast.LENGTH_SHORT).show();
            }
        }
    }
    private void requestPermissionByHand() {
        //判断当前系统的版本
        if (Build.VERSION.SDK_INT >= 23) {//6.0以上
            int checkReadStoragePermission = ContextCompat.checkSelfPermission(
                    MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE);
            //如果读取没有被授予
            if (checkReadStoragePermission != PackageManager.PERMISSION_GRANTED) {//如果没有权限
                ActivityCompat.requestPermissions(
                        MainActivity.this, new String[]{
                                Manifest.permission.READ_EXTERNAL_STORAGE
                        }, REQ_READ_EXTERNAL_STORAGE);//申请权限
            } else {
                new ScanMusicTask(MainActivity.this);//创建异步任务扫描手机
            }
        }
        else{
            new ScanMusicTask(MainActivity.this).execute();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, final String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_READ_EXTERNAL_STORAGE) {
            // 如果请求被取消了，那么结果数组就是空的
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // 权限被授予了
                if (SongsCollector.size() == 0) {
                    new ScanMusicTask(MainActivity.this).execute();
                }
            } else {
                Toast.makeText(MainActivity.this, "读存储权限申请失败", Toast.LENGTH_SHORT).show();
            }
        }
    }
    private static class ScanMusicTask extends AsyncTask<Void,Void,Boolean>  {
        private final WeakReference<MainActivity> displayActivityWeakReference ;
        ScanMusicTask(MainActivity displayActivity){
            displayActivityWeakReference = new WeakReference<>(displayActivity);
        }
        @Override
        protected void onPreExecute() {
            MainActivity displayActivity = displayActivityWeakReference.get();
        }
        @Override
        protected Boolean doInBackground(Void... voids) {//耗时操作在此方法中进行
            MainActivity displayActivity = displayActivityWeakReference.get();
            ContentResolver contentResolver = displayActivity.getContentResolver();
            try (Cursor cursor = contentResolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    null, null, null, null)) {
                if (cursor != null) {
                    while (cursor.moveToNext()) {
                        @SuppressLint("Range") int isMusic = cursor.getInt(cursor.getColumnIndex(MediaStore.Audio.Media.IS_MUSIC));
                        @SuppressLint("Range") long duration = cursor.getLong(cursor.getColumnIndex(MediaStore.Audio.Media.DURATION));
                        if (isMusic != 0 && duration >= 0.1 * 60 * 1000) {
                            String dataPath = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA));
                            if (SongsCollector.isContainSong(dataPath)) {
                                continue;
                            }
                            String title = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE));
                            String artist = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST));
                            Song song = new Song(title, artist, duration, dataPath,false,
                                    PictureDealHelper.getAlbumPicture(dataPath,96,96),false,false);
                            if(!SongsCollector.isContainSong(song.getDataPath())){
                                SongsCollector.addSong(song);
                                if(song.getAlbum_icon() == null){
                                    song.setFlagDefaultAlbumIcon(true);
                                }
                                displayActivityWeakReference.get().handleDbFunction.saveSong(song);
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return true;
        }
        @Override
        protected void onPostExecute(Boolean result) {
            MainActivity displayActivity = displayActivityWeakReference.get();
            if(result){
                Toast.makeText(displayActivity,"歌曲扫描完毕",Toast.LENGTH_SHORT).show();
                for(int i = 0; i < SongsCollector.size(); i ++){
                    Song s = SongsCollector.getSong(i);
                    if(s.getAlbum_icon() == null){
                        Bitmap b = PictureDealHelper.getAlbumPicture(displayActivity,
                                s.getDataPath(),96,96,false);
                        s.setAlbum_icon(b);
                    }
                }
                displayActivity.initMySongListView();
                if (SongsCollector.size() == 0) {
                    Toast.makeText(displayActivity, "本机无歌曲,请下载！", Toast.LENGTH_SHORT).show();
                }
            }else{
                Toast.makeText(displayActivity,"默认专辑图片出错",Toast.LENGTH_SHORT).show();
            }
        }
    }
    private void initMySongListView(){
        final ListView main_song_list_view = findViewById(R.id.main_song_list_view);
        adapter_main_song_list_view = new SongAdapter(MainActivity.this,R.layout.song_list_item,SongsCollector.getSongsList());
        main_song_list_view.setAdapter(adapter_main_song_list_view);
        main_song_list_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

            }
        });
        //item内部的more_options按钮点击
        adapter_main_song_list_view.setOnItemMoreOptionsClickListener(new SongAdapter.OnItemMoreOptionsListener() {
            @Override
            public void onMoreOptionsClick(final int position) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this)
                        .setTitle("请确认!")
                        .setIcon(R.drawable.danger)
                        .setMessage("确认要从本地列表中删除此歌曲吗?")
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if(handleDbFunction != null){
                                    handleDbFunction.removeSong(SongsCollector.getSong(position).getDataPath());
                                }
                                SongsCollector.removeSong(position);
                                if(adapter_main_song_list_view != null){
                                    adapter_main_song_list_view.notifyDataSetChanged();
                                }
                                if(main_song_list_view != null){
                                    main_song_list_view.invalidate();
                                }
                                Toast.makeText(MainActivity.this,"已删除,点击刷新按钮可找回",Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Toast.makeText(MainActivity.this,"下次不要点错了哦",Toast.LENGTH_SHORT).show();
                            }
                        });
                builder.create().show();
            }
        });
    }
}