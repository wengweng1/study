package com.example.localonlinesong.localonlinesong.adapter;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import com.example.localonlinesong.localonlinesong.R;
import com.example.localonlinesong.localonlinesong.models.Song;

import java.util.List;

public class SongAdapter extends ArrayAdapter<Song> {
    private int resourceId;//用来放置布局文件的id
    private Context context;
    private OnItemMoreOptionsListener onItemMoreOptionsListener;
    public SongAdapter(Context context, int resourceId, List<Song> objects) {
        super(context, resourceId, objects);
        this.context = context;
        this.resourceId = resourceId;
    }
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        Song song = getItem(position); // 获取当前项的Song实例
        View view;//子项布局对象
        ViewHolder viewHolder;//内部类对象
        if (convertView == null) {//如果是第一次加载
            view = LayoutInflater.from(getContext()).inflate(resourceId, parent, false);//布局对象化
            viewHolder = new ViewHolder();
            viewHolder.songImage = view.findViewById(R.id.song_image);
            viewHolder.songName = view.findViewById (R.id.title);
            viewHolder.songAuthor=view.findViewById(R.id.artist);
            viewHolder.more_options = view.findViewById(R.id.more_options);
            view.setTag(viewHolder); // 将ViewHolder存储在View中
        } else {//不是第一次加载，即布局文件已经加载，可以利用
            view = convertView;
            viewHolder = (ViewHolder) view.getTag();
        }
        if(song!=null && viewHolder!=null){
            //传入具体信息
            viewHolder.songImage.setImageBitmap(song.getAlbum_icon());//列表每一项的图标
            viewHolder.songName.setText(song.getTitle());//歌名
            viewHolder.songAuthor.setText(song.getArtist());//歌手
            //设置两个文本的字体style
            viewHolder.songName.setTypeface(Typeface.DEFAULT_BOLD);
            viewHolder.songAuthor.setTypeface(Typeface.DEFAULT_BOLD);
            //设定更多选项按钮的点击事件
            viewHolder.more_options.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(onItemMoreOptionsListener != null){
                        onItemMoreOptionsListener.onMoreOptionsClick(position);
                    }
                }
            });
        }
        return view;
    }

    public interface OnItemMoreOptionsListener {
        void onMoreOptionsClick(int position);
    }

    public void setOnItemMoreOptionsClickListener(OnItemMoreOptionsListener m) {
        this.onItemMoreOptionsListener = m;
    }
    static class ViewHolder {//为了同时返回多个控件，Java一次只能返回一个数据
        ImageView songImage;
        TextView songName;
        TextView songAuthor;
        ImageView more_options;
    }
}
