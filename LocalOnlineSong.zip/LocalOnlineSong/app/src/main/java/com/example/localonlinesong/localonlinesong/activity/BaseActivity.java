package com.example.localonlinesong.localonlinesong.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;

import com.example.localonlinesong.localonlinesong.models.ActivityCollector;

public class BaseActivity extends AppCompatActivity {

    private static Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.w("BaseActivity",getClass().getSimpleName()+"进入了onCreate");
        ActivityCollector.addActivity(this);
    }
    @Override
    protected void onStart(){
        super.onStart();
        Log.w("BaseActivity",getClass().getSimpleName()+"进入了onStart");
    }
    @Override
    protected void onResume(){
        super.onResume();
        Log.w("BaseActivity",getClass().getSimpleName()+"进入了onResume");
    }
    @Override
    protected void onPause(){
        super.onPause();
        Log.w("BaseActivity",getClass().getSimpleName()+"进入了onPause");
    }
    @Override
    protected void onStop(){
        super.onStop();
        Log.w("BaseActivity",getClass().getSimpleName()+"进入了onStop");
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.w("BaseActivity",getClass().getSimpleName()+"进入了onDestroy");
        ActivityCollector.removeActivity(this);//remove oneself from the activity manager
    }
    @Override
    protected void onRestart(){
        Log.w("BaseActivity",getClass().getSimpleName()+"进入了onRestart");
        super.onRestart();
    }
    @Override
    public void onBackPressed(){
        super.onBackPressed();
        Log.w("BaseActivity", getClass().getSimpleName()+"进入onBackPressed");
    }
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        Log.w("BaseActivity", getClass().getSimpleName()+"进入onSaveInstanceState");
    }
    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState){
        super.onRestoreInstanceState(savedInstanceState);
        Log.w("BaseActivity", getClass().getSimpleName()+"进入onRestoreInstanceState");
    }
    public static Context getContext() {
        return context;
    }

}