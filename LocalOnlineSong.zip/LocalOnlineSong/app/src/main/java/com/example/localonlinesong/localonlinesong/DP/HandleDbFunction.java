package com.example.localonlinesong.localonlinesong.DP;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.localonlinesong.localonlinesong.models.Song;
import com.example.localonlinesong.localonlinesong.utils.PictureDealHelper;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

public class HandleDbFunction {
    public static final String DB_NAME = "Zhuo_Music";
    public static final int VERSION = 1;
    private volatile static HandleDbFunction handleDbFunction;
    private SQLiteDatabase db;
    private WeakReference<Context> weakReference;
    private HandleDbFunction(Context context){
        weakReference = new WeakReference<>(context);

    }
    public static HandleDbFunction getInstance(Context context){
        if(handleDbFunction == null){
            synchronized (HandleDbFunction.class){
                if(handleDbFunction ==null){
                    handleDbFunction = new HandleDbFunction(context);
                }
            }
        }
        return handleDbFunction;
    }
    public boolean isSONGS_Null(){
        if(db != null){
            Cursor cursor = db.query("SONGS",null,null,null,null,null,null);
            if(cursor.moveToFirst()){
                return false;//不为空
            }
            cursor.close();
        }
        return true;//空
    }
    public void saveSong(Song song){
        if(song != null && db != null){
            ContentValues values = new ContentValues();
            values.put("title",song.getTitle());
            values.put("artist",song.getArtist());
            values.put("duration",song.getDuration());
            values.put("dataPath",song.getDataPath());
            if(song.isLove())
                values.put("isLove","true");
            else
                values.put("isLove","false");
            if(song.isDefaultAlbumIcon())
                values.put("isDefaultAlbumIcon","true");
            else
                values.put("isDefaultAlbumIcon","false");

        }
    }
    public void removeSong(String dataPath){
        if(dataPath != null && db != null){
            db.delete("SONGS","dataPath=?",new String[]{dataPath});
        }
    }
    public void setLove(String dataPath,String flag){
        ContentValues values = new ContentValues();
        values.put("isLove",flag);

    }
    @SuppressLint("Range")
    public ArrayList<Song> loadMyLoveSongs(){//加载自己收藏的歌曲
        ArrayList<Song> list = new ArrayList<>();
        if(db != null){
            Cursor cursor = db.query("SONGS",null,"isLove =?",new String[]{"true"},null,null,null);
            while (cursor.moveToFirst()){
                    Song song = new Song();
                    song.setTitle(cursor.getString(cursor.getColumnIndex("title")));
                    song.setArtist(cursor.getString(cursor.getColumnIndex("artist")));
                    song.setDuration(cursor.getLong(cursor.getColumnIndex("duration")));
                    song.setDataPath(cursor.getString(cursor.getColumnIndex("dataPath")));
                    song.setOnline(false);
                    song.setLove(true);
                    String flag2 = cursor.getString(cursor.getColumnIndex("isDefaultAlbumIcon"));
                    if(flag2.equals("true"))
                        song.setFlagDefaultAlbumIcon(true);
                    else
                        song.setFlagDefaultAlbumIcon(false);
                    song.setAlbum_icon(PictureDealHelper.getAlbumPicture(weakReference.get(),song.getDataPath(),96,96,false));
                    list.add(song);
            }
            cursor.close();
        }
        return list;
    }
    @SuppressLint("Range")
    public ArrayList<Song> loadAllSongs(){//加载全部歌曲
        ArrayList<Song> list = new ArrayList<>();
        if(db != null){
            Cursor cursor = db.query("SONGS",null,null,null,null,null,null);
            if(cursor.moveToFirst()){
                do{
                    Song song = new Song();
                    song.setTitle(cursor.getString(cursor.getColumnIndex("title")));
                    song.setArtist(cursor.getString(cursor.getColumnIndex("artist")));
                    song.setDuration(cursor.getLong(cursor.getColumnIndex("duration")));
                    song.setDataPath(cursor.getString(cursor.getColumnIndex("dataPath")));
                    song.setOnline(false);
                    String flag1 = cursor.getString(cursor.getColumnIndex("isLove"));
                    if(flag1.equals("true"))
                        song.setLove(true);
                    else
                        song.setLove(false);
                    String flag2 = cursor.getString(cursor.getColumnIndex("isDefaultAlbumIcon"));
                    if(flag2.equals("true")){
                        song.setFlagDefaultAlbumIcon(true);
                    }
                    else{
                        song.setFlagDefaultAlbumIcon(false);
                    }
                    song.setAlbum_icon(PictureDealHelper.getAlbumPicture(weakReference.get(),song.getDataPath(),96,96,false));
                    list.add(song);
                }while(cursor.moveToNext());
            }
            cursor.close();
        }
        return list;
    }
}
