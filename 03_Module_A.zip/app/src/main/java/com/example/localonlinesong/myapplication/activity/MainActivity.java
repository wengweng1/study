package com.example.localonlinesong.myapplication.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.localonlinesong.myapplication.R;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = findViewById(R.id.btn);
        imageView = findViewById(R.id.img);
        button.setOnClickListener(new View.OnClickListener() {
            boolean flag = true;
            @Override
            public void onClick(View view) {
                if (flag){
                    imageView.setImageResource(R.mipmap.sjh);
                    flag=false;
                }
                else {
                    imageView.setImageResource(R.mipmap.sj);
                    flag=true;
                }

            }
        });
        textView = findViewById(R.id.sj);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                int year,month,date;
                year=calendar.get(1);
                month=calendar.get(2);
                date=calendar.get(5);
                DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    String month;
                    String date;
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        if (i1+1<10){
                            month="0"+(i1+1);
                        }
                        else {
                            month= String.valueOf(i1+1);
                        }
                        if (i2<10){
                            date = "0"+i2;
                        }
                        else {
                            date = String.valueOf(i2);
                        }
                        String d = i+"-"+month+"-"+date;
                        textView.setText("出发时间:"+d);
                    }
                },year,month,date);
                datePickerDialog.show();
            }
        });
    }
}