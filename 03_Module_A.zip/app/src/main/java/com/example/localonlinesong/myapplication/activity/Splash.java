package com.example.localonlinesong.myapplication.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.localonlinesong.myapplication.R;
import com.example.localonlinesong.myapplication.adapter.SplashAdapter;

import java.util.ArrayList;
import java.util.List;

public class Splash extends AppCompatActivity {
    private List<View> viewList;
    private ViewPager viewPager;
    private Button btn;
    private SplashAdapter splashAdapter;
    private ImageView img,img1,img2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        initView();
        img.setImageResource(R.mipmap.login_point_selected);
        intiDo();
    }
    private void initView(){
        LayoutInflater layoutInflater = LayoutInflater.from(this);
        viewList = new ArrayList<>();
        viewList.add(layoutInflater.inflate(R.layout.first,null));
        viewList.add(layoutInflater.inflate(R.layout.second,null));
        viewList.add(layoutInflater.inflate(R.layout.third,null));
        splashAdapter = new SplashAdapter(viewList);
        viewPager = findViewById(R.id.viewpagegr);
        viewPager.setAdapter(splashAdapter);
        img = findViewById(R.id.first);
        img1 = findViewById(R.id.second);
        img2 = findViewById(R.id.thrid);
        btn = viewList.get(2).findViewById(R.id.btn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Splash.this,Login.class));
                finish();
            }
        });
        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (position==0){
                    img.setImageResource(R.mipmap.login_point_selected);
                    img1.setImageResource(R.mipmap.login_point);
                    img2.setImageResource(R.mipmap.login_point);
                }
                if (position==1){
                    img1.setImageResource(R.mipmap.login_point_selected);
                    img.setImageResource(R.mipmap.login_point);
                    img2.setImageResource(R.mipmap.login_point);
                }
                if (position==2){
                    img2.setImageResource(R.mipmap.login_point_selected);
                    img1.setImageResource(R.mipmap.login_point);
                    img.setImageResource(R.mipmap.login_point);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }
    private void intiDo(){
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewPager.setCurrentItem(0);
            }
        });
        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewPager.setCurrentItem(1);
            }
        });
        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                viewPager.setCurrentItem(2);
            }
        });
    }
}